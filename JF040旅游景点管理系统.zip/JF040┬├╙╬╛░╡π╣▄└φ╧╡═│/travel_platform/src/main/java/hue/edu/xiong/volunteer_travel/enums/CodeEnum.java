package hue.edu.xiong.volunteer_travel.enums;

public interface CodeEnum {
    Integer getCode();
}

package hue.edu.xiong.volunteer_travel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolunteerTravelApplication {

    public static void main(String[] args) {
        SpringApplication.run(VolunteerTravelApplication.class, args);
    }

}
